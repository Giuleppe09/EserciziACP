package service;

public interface IPrinter{
    
    public boolean print(String docName);
    public int getPort();
} 
